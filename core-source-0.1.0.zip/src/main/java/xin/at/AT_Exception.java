package xin.at;


public class AT_Exception extends Exception {

	private static final long serialVersionUID = 1L;

	public AT_Exception(String message){
	     super(message);
	  }

	}